tags= ['edison', 'failure', 'inspirational', 'paraphrased']
tags_fixed=[]
fixed_tags=' '.join(tags)
print(fixed_tags)